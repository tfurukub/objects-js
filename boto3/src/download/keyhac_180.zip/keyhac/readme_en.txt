"Keyhac" - Python powered key customization tool

Author: craftware
Contact: craftware@gmail.com
Software type: Free software
Supported OS: Windows 10  32bit/64bit
Dev env: Python + Visual Studio 2019
Website: http://sites.google.com/site/craftware/

For detailed information, please refer the user document.
doc/en/index.html


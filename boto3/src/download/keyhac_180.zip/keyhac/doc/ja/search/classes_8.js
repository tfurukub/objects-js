var searchData=
[
  ['subprocess_259',['SubProcess',['../classckit_1_1ckit__subprocess_1_1_sub_process.html',1,'ckit::ckit_subprocess']]],
  ['synccall_260',['SyncCall',['../classckit_1_1ckit__threadutil_1_1_sync_call.html',1,'ckit::ckit_threadutil']]]
];

var searchData=
[
  ['terminateprocess_211',['terminateProcess',['../group__misc.html#ga5f7e1c911d7db8d2b466acc31a50601d',1,'ckit::ckit_misc']]],
  ['textencoding_212',['TextEncoding',['../classckit_1_1ckit__misc_1_1_text_encoding.html',1,'ckit::ckit_misc']]]
];

var searchData=
[
  ['miscellaneous_20features_457',['Miscellaneous features',['../group__misc.html',1,'']]]
];

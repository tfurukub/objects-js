var group__subprocess =
[
    [ "SubProcess", "classckit_1_1ckit__subprocess_1_1_sub_process.html", [
      [ "__init__", "classckit_1_1ckit__subprocess_1_1_sub_process.html#ad06a209b735da916536c7717bd44bf6e", null ],
      [ "__call__", "classckit_1_1ckit__subprocess_1_1_sub_process.html#a66b2fc5e7e096cac91755849fbf6de76", null ],
      [ "cancel", "classckit_1_1ckit__subprocess_1_1_sub_process.html#a807ed97eee69cbd1e4b9077ac361d77c", null ]
    ] ]
];
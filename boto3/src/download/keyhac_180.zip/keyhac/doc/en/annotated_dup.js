var annotated_dup =
[
    [ "ckit", null, [
      [ "ckit_misc", null, [
        [ "FileReaderLock", "classckit_1_1ckit__misc_1_1_file_reader_lock.html", "classckit_1_1ckit__misc_1_1_file_reader_lock" ],
        [ "TextEncoding", "classckit_1_1ckit__misc_1_1_text_encoding.html", null ],
        [ "UnicodeRange", "classckit_1_1ckit__misc_1_1_unicode_range.html", null ],
        [ "WordBreak", "classckit_1_1ckit__misc_1_1_word_break.html", null ]
      ] ],
      [ "ckit_subprocess", null, [
        [ "SubProcess", "classckit_1_1ckit__subprocess_1_1_sub_process.html", "classckit_1_1ckit__subprocess_1_1_sub_process" ]
      ] ],
      [ "ckit_threadutil", null, [
        [ "CronItem", "classckit_1_1ckit__threadutil_1_1_cron_item.html", "classckit_1_1ckit__threadutil_1_1_cron_item" ],
        [ "CronTable", "classckit_1_1ckit__threadutil_1_1_cron_table.html", "classckit_1_1ckit__threadutil_1_1_cron_table" ],
        [ "JobItem", "classckit_1_1ckit__threadutil_1_1_job_item.html", "classckit_1_1ckit__threadutil_1_1_job_item" ],
        [ "JobQueue", "classckit_1_1ckit__threadutil_1_1_job_queue.html", "classckit_1_1ckit__threadutil_1_1_job_queue" ],
        [ "SyncCall", "classckit_1_1ckit__threadutil_1_1_sync_call.html", "classckit_1_1ckit__threadutil_1_1_sync_call" ]
      ] ]
    ] ],
    [ "keyhac_clipboard", null, [
      [ "cblister_ClipboardHistory", "classkeyhac__clipboard_1_1cblister___clipboard_history.html", "classkeyhac__clipboard_1_1cblister___clipboard_history" ],
      [ "cblister_FixedPhrase", "classkeyhac__clipboard_1_1cblister___fixed_phrase.html", null ]
    ] ],
    [ "keyhac_keymap", null, [
      [ "Keymap", "classkeyhac__keymap_1_1_keymap.html", "classkeyhac__keymap_1_1_keymap" ],
      [ "WindowKeymap", "classkeyhac__keymap_1_1_window_keymap.html", "classkeyhac__keymap_1_1_window_keymap" ]
    ] ],
    [ "keyhac_listwindow", null, [
      [ "ListWindow", "classkeyhac__listwindow_1_1_list_window.html", "classkeyhac__listwindow_1_1_list_window" ]
    ] ],
    [ "pyauto", null, [
      [ "pyauto_input", null, [
        [ "Char", "classpyauto_1_1pyauto__input_1_1_char.html", null ],
        [ "Key", "classpyauto_1_1pyauto__input_1_1_key.html", null ],
        [ "KeyDown", "classpyauto_1_1pyauto__input_1_1_key_down.html", null ],
        [ "KeyUp", "classpyauto_1_1pyauto__input_1_1_key_up.html", null ],
        [ "MouseHorizontalWheel", "classpyauto_1_1pyauto__input_1_1_mouse_horizontal_wheel.html", null ],
        [ "MouseLeftClick", "classpyauto_1_1pyauto__input_1_1_mouse_left_click.html", null ],
        [ "MouseLeftDown", "classpyauto_1_1pyauto__input_1_1_mouse_left_down.html", null ],
        [ "MouseLeftUp", "classpyauto_1_1pyauto__input_1_1_mouse_left_up.html", null ],
        [ "MouseMiddleClick", "classpyauto_1_1pyauto__input_1_1_mouse_middle_click.html", null ],
        [ "MouseMiddleDown", "classpyauto_1_1pyauto__input_1_1_mouse_middle_down.html", null ],
        [ "MouseMiddleUp", "classpyauto_1_1pyauto__input_1_1_mouse_middle_up.html", null ],
        [ "MouseMove", "classpyauto_1_1pyauto__input_1_1_mouse_move.html", null ],
        [ "MouseRightClick", "classpyauto_1_1pyauto__input_1_1_mouse_right_click.html", null ],
        [ "MouseRightDown", "classpyauto_1_1pyauto__input_1_1_mouse_right_down.html", null ],
        [ "MouseRightUp", "classpyauto_1_1pyauto__input_1_1_mouse_right_up.html", null ],
        [ "MouseWheel", "classpyauto_1_1pyauto__input_1_1_mouse_wheel.html", null ]
      ] ],
      [ "Hook", "classpyauto_1_1_hook.html", "classpyauto_1_1_hook" ],
      [ "Image", "classpyauto_1_1_image.html", "classpyauto_1_1_image" ],
      [ "Input", "classpyauto_1_1_input.html", null ],
      [ "Window", "classpyauto_1_1_window.html", "classpyauto_1_1_window" ]
    ] ]
];
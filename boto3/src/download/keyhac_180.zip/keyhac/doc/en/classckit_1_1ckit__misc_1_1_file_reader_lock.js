var classckit_1_1ckit__misc_1_1_file_reader_lock =
[
    [ "__init__", "classckit_1_1ckit__misc_1_1_file_reader_lock.html#a3164cf6799ee225be22b2beb6bdf219d", null ],
    [ "unlock", "classckit_1_1ckit__misc_1_1_file_reader_lock.html#a3aa5c7a8b194766605bd44948ae9588c", null ]
];